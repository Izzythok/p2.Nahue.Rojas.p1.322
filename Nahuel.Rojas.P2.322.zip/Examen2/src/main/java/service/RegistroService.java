/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Predicate;

public interface RegistroService<T extends Comparable<? super T>> {

    void agregar(T elemento);

    T obtener(int indice);

    T eliminar(int indice);

    int tamanio();

    void paraCadaElemento(Consumer<T> accion);

    ArrayList<T> filtrar(Predicate<T> criterio);

    void ordenarNatural();

    void ordenar(Comparator<? super T> comparador);
}
