
package persistence;


import service.CSVSerializable;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class RegistroPersistence {

    // ───────── Binario ─────────

    public static <T extends Serializable> void guardarEnArchivo(List<T> elementos, String ruta)
            throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(new ArrayList<>(elementos));
        }
    }

 
    public static <T extends Serializable> ArrayList<T> cargarDesdeArchivo(String ruta)
            throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            Object obj = ois.readObject();
            if (obj instanceof ArrayList<?>) {
                return (ArrayList<T>) obj;
            }
            throw new IOException("Formato de archivo inválido (no es ArrayList)");
        }
    }

    // ───────── CSV ─────────

    public static <T extends CSVSerializable> void guardarEnCSV(List<T> elementos, String ruta)
            throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))) {
            for (T e : elementos) {
                bw.write(e.toCSV());
                bw.newLine();
            }
        }
    }

    public static <T> ArrayList<T> cargarDesdeCSV(String ruta, Function<String, T> mapeador)
            throws IOException {
        ArrayList<T> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.isBlank()) continue;
                lista.add(mapeador.apply(linea));
            }
        }
        return lista;
    }
}