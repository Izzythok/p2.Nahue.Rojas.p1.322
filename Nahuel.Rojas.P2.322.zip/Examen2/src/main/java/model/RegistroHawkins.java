
package model;



import service.CSVSerializable;
import persistence.RegistroPersistence;
import service.RegistroService;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class RegistroHawkins<T extends CSVSerializable & Serializable & Comparable<? super T>>
        implements RegistroService<T>, Serializable {

    private final ArrayList<T> elementos = new ArrayList<>();

    @Override
    public void agregar(T elemento) {
        elementos.add(elemento);
    }

    @Override
    public T obtener(int indice) {
        return elementos.get(indice);
    }

    @Override
    public T eliminar(int indice) {
        return elementos.remove(indice);
    }

    @Override
    public int tamanio() {
        return elementos.size();
    }

    @Override
    public void paraCadaElemento(Consumer<T> accion) {
        for (T e : elementos) {
            accion.accept(e);
        }
    }

    @Override
    public ArrayList<T> filtrar(Predicate<T> criterio) {
        ArrayList<T> resultado = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    @Override
    public void ordenarNatural() {
        elementos.sort(null);
    }

    @Override
    public void ordenar(Comparator<? super T> comparador) {
        elementos.sort(comparador);
    }

    public ArrayList<T> getElementos() {
        return elementos;
    }

    public void reemplazarElementos(ArrayList<T> nuevos) {
        elementos.clear();
        elementos.addAll(nuevos);
    }

    public void guardarEnArchivo(String ruta) throws IOException {
        RegistroPersistence.guardarEnArchivo(elementos, ruta);
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        ArrayList<T> cargados = RegistroPersistence.cargarDesdeArchivo(ruta);
        reemplazarElementos(cargados);
    }

    public void guardarEnCSV(String ruta) throws IOException {
        RegistroPersistence.guardarEnCSV(elementos, ruta);
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> mapeador) throws IOException {
        ArrayList<T> cargados = RegistroPersistence.cargarDesdeCSV(ruta, mapeador);
        reemplazarElementos(cargados);
    }
}