

package prueba.examen.examen2;

import model.CasoHawkins;
import model.ClasificacionCaso;
import model.RegistroHawkins;

import java.io.IOException;
import java.util.Comparator;

public class Examen2 {

    public static void main(String[] args) {
        try {
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>();

            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr. Brenner",ClasificacionCaso.APERTURA_DIMENSIONAL));

            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr. Owens",ClasificacionCaso.SUJETO_PSIQUICO));

            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper",ClasificacionCaso.ENTIDAD_HOSTIL));

            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales", "Nancy Wheeler",ClasificacionCaso.FENOMENO_ELECTROMAGNETICO));

            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque", "Joyce Byers",ClasificacionCaso.DESAPARICION));

            System.out.println("Casos registrados:");
            registro.paraCadaElemento(System.out::println);

            System.out.println("\nCasos tipo SUJETO_PSIQUICO:");
            registro.filtrar(c ->c.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO).forEach(System.out::println);

            System.out.println("\nCasos que contienen 'portal':");
            registro.filtrar(c ->c.getTitulo().toLowerCase().contains("portal")).forEach(System.out::println);

            System.out.println("\nCasos ordenados por ID:");
            registro.ordenar(Comparator.comparingInt(CasoHawkins::getId));
            registro.paraCadaElemento(System.out::println);

            System.out.println("\nCasos ordenados por título:");
            registro.ordenar(Comparator.comparing(CasoHawkins::getTitulo));
            registro.paraCadaElemento(System.out::println);

            String rutaBin = "src/main/java/resources/casos.dat";
            String rutaCsv = "src/main/java/resources/casos.csv";

            registro.guardarEnArchivo(rutaBin);

            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>();
            cargado.cargarDesdeArchivo(rutaBin);

            System.out.println("\nCasos cargados desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);

            registro.guardarEnCSV(rutaCsv);

            cargado.cargarDesdeCSV(rutaCsv, model.CasoHawkins::fromCSV);

            System.out.println("\nCasos cargados desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
