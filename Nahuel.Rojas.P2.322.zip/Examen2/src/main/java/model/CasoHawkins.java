
package model;

import service.CSVSerializable;
import java.io.Serializable;

public class CasoHawkins implements CSVSerializable, Serializable, Comparable<CasoHawkins> {

    private int id;
    private String titulo;
    private String investigador;
    private ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getInvestigador() {
        return investigador;
    }

    public ClasificacionCaso getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(ClasificacionCaso clasificacion) {
        this.clasificacion = clasificacion;
    }

    @Override
    public int compareTo(CasoHawkins otro) {
        return Integer.compare(this.id, otro.id);
    }

    @Override
    public String toString() {
        return String.format(
                "CasoHawkins{id=%d, titulo='%s', investigador='%s', clasificacion=%s}",
                id, titulo, investigador, clasificacion
        );
    }

    // ───────── CSV ─────────

    @Override
    public String toCSV() {
        
        return id + "," + titulo + "," + investigador + "," + clasificacion.name();
    }

    public static CasoHawkins fromCSV(String linea) {
        
        if (linea == null || linea.isBlank()) {
            throw new IllegalArgumentException("Línea CSV vacía o nula");
        }
        String[] partes = linea.split(",", 4);
        if (partes.length != 4) {
            throw new IllegalArgumentException("Formato CSV inválido: " + linea);
        }
        int id = Integer.parseInt(partes[0].trim());
        String titulo = partes[1].trim();
        String investigador = partes[2].trim();
        ClasificacionCaso clasificacion = ClasificacionCaso.valueOf(partes[3].trim());
        return new CasoHawkins(id, titulo, investigador, clasificacion);
    }
}
